from django.shortcuts import render,redirect
from .models import Bo
from django.db.models import Q
from django.core.paginator import Paginator
# Create your views here.
def index(request,id):
    if id=='':
        id=1
    posts=Bo.objects.filter(isDelete=False)
    p=Paginator(posts,2)
    pag=p.page(id)
    total=p.num_pages
    pages=p.page_range
    context={'bo':pag,'total':total,'pages':pages}
    return render(request,'index.html',context)
def post_boke(request):
    title=request.POST.get('title')
    content=request.POST.get('content')
    bo=Bo()
    bo.title=title
    bo.content=content
    bo.save()
    return redirect('/index/')
def delete_boke(request,id):
    bo=Bo.objects.get(pk=id)
    #bo.delete()
    bo.isDelete=True
    bo.save()
    return redirect('/index/')
def edit_boke(request,id):
    bo=Bo.objects.get(pk=id)
    context={'bo':bo}
    return render(request,'edit.html',context)
def edit_success(request):
    id=request.POST.get('id')
    bo=Bo.objects.get(pk=int(id))
    title=request.POST.get('title')
    content=request.POST.get('content')
    category=request.POST.get('category')
    publish_date=request.POST.get('publish')
    bo.title=title
    bo.content=content
    bo.category=category
    bo.publish_date=publish_date
    bo.save()
    return redirect('/index/')
def search(request):
    word=request.POST.get('keyboard')
    bo=Bo.objects.filter(Q(title__contains=word)|Q(content__contains=word)).filter(isDelete=False)
    context={'bo':bo}
    return render(request,'index.html',context)


