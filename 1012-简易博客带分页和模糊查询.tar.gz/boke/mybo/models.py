from django.db import models

# Create your models here.
class  Bo(models.Model):
    title=models.CharField(max_length=100)
    content=models.CharField(max_length=288)
    pic=models.ImageField(upload_to='media/',default='')
    publish_date=models.DateField(auto_now_add=True)
    author=models.CharField(max_length=20,default='小黄人')
    category=models.CharField(max_length=20,default='心得笔记')
    isDelete=models.BooleanField(default=False)
    class Meta:
        db_table='bo'

