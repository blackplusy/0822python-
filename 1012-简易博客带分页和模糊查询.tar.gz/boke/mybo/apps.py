from django.apps import AppConfig


class MyboConfig(AppConfig):
    name = 'mybo'
