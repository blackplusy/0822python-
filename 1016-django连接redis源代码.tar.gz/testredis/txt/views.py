from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from django.core.cache import cache
def index(request):
    cache.set('username','admin')
    print(cache.get('username'))
    return HttpResponse('ok')