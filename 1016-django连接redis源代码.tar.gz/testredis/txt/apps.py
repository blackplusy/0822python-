from django.apps import AppConfig


class TxtConfig(AppConfig):
    name = 'txt'
