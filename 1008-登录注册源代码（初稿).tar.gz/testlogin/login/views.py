# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import UserInfo
# Create your views here.
def login(request):
    return render(request,'login.html')
def register(request):
    return render(request,'regiester.html')
def register_handler(request):
    username=request.POST.get('username')
    password=request.POST.get('password')
    print(username)
    print(password)
    user=UserInfo()
    user.username=username
    user.password=password
    user.save()
    return redirect('/login/')
def login_handler(request):
    username=request.POST.get('username')
    names=UserInfo.objects.filter(username=username)
    if len(names)!=0:
        return HttpResponse('<h1>login success!</h1>')
    else:
        return redirect('/register/')