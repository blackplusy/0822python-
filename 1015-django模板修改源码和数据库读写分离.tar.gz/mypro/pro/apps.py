from django.apps import AppConfig


class ProConfig(AppConfig):
    name = 'pro'
