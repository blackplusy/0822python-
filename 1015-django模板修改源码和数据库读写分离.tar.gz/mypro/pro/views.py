from django.shortcuts import render

# Create your views here.
def login(request):
    return render(request,'login.html')
def register(request):
    return render(request,'register.html')
def info(request):
    context={'s':1}
    return render(request,'user_center_info.html',context)
def order(request):
    context={'s':2}
    return render(request,'user_center_order.html',context)
def site(request):
    context={'s':3}
    return render(request,'user_center_site.html',context)