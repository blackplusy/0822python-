# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class UserInfo(models.Model):
    '''
        create table userinfo(username varchar(20)
    '''
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)


