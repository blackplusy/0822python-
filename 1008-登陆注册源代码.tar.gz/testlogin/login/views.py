# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import UserInfo
from hashlib import md5
# Create your views here.
def login(request):
    return render(request,'login.html')
def register(request):
    return render(request,'regiester.html')
def register_handler(request):
    username=request.POST.get('username')
    password=request.POST.get('password')
    repassword=request.POST.get('repassword')

    if password==repassword:

        uinfo = UserInfo.objects.filter(username=username)
        if len(uinfo)==0:

            user=UserInfo()
            user.username=username
            pwd=md5()
            pwd.update(password)
            user.password=pwd.hexdigest()
            user.save()
            return redirect('/login/')
        else:

            context={'error':'username is exists!'}
            return render(request,'regiester.html',context)

    else:
        print(5)
        context={'error':'password not equals to repassword'}
        return render(request, 'regiester.html',context)

def login_handler(request):
    username=request.POST.get('username')
    password=request.POST.get('password')
    names=UserInfo.objects.filter(username=username)
    pwd=md5()
    pwd.update(password)
    if len(names)!=0:
        if names[0].username==username and names[0].password==pwd.hexdigest():
            return HttpResponse('<h1>login success!</h1>')
        else:
            context={'error':'username or password wrong!'}
            return render(request,'login.html',context)
    else:
        context={'error':'username not exists,please register!'}
        return render(request, 'regiester.html', context)