from django.contrib import admin
from tst.models import *
# Register your models here.
admin.site.register(Student)
admin.site.register(Score)
admin.site.register(Course)
admin.site.register(Teacher)