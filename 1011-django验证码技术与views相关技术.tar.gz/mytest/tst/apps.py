from django.apps import AppConfig


class TstConfig(AppConfig):
    name = 'tst'
