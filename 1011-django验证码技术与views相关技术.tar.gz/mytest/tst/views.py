from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import os
from  mytest.settings import BASE_DIR
from PIL import Image,ImageDraw,ImageFont
import random
from io import BytesIO
# Create your views here.

def index(request):
    # 如果有cookie直接显示本页面，如果没有user就到index页面
    u=request.COOKIES.get('user')
    s=request.session.get('users','')
    print(s)
    if s!='':
        return HttpResponse('你已登录过了')
    else:
        return render(request,'index.html')
def index_success(request):
    username = request.POST.get('username')
    lover = request.POST.getlist('lover')
    file=request.FILES['pic']
    str1 = ''
    for l in lover:
        str1+=l+' ;'
    resp=HttpResponse(username+'     '+str1+'   ok')
    resp.set_cookie('user',username)
    request.session['users']=username
    f=open(os.path.join(BASE_DIR,'images/'+file.name),'wb')
    for c in file.chunks():
        f.write(c)


    return resp
def clear_cookie(request):
    resp=HttpResponse('ok')
    resp.set_cookie('user','')
    request.session.clear()
    return resp
def verifyCode(request):
    bgcolor=(random.randrange(0,100),random.randrange(0,100),255)
    width=140
    height=50
    im=Image.new('RGB',(width,height),bgcolor)
    draw=ImageDraw.Draw(im)
    for i in range(0,100):
        xy=(random.randrange(0,width),random.randrange(0,height))
        fillcolor=(random.randrange(0,255),255,random.randrange(0,255))
        draw.point(xy,fill=fillcolor)
        #draw.line(xy,fill=fillcolor,width=1)
    strs='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    randstr=''
    for j in range(0,4):
        ind=random.randrange(0,len(strs))
        randstr+=strs[ind]

    fonts=ImageFont.truetype(font='FreeSans.ttf',size=30)
    fontcolor=(255,random.randrange(0,255),random.randrange(0,255))
    draw.text((5,1),randstr[0],fill=fontcolor,font=fonts)
    draw.text((40,23),randstr[1],fill=fontcolor,font=fonts)
    draw.text((75,7),randstr[2],fill=fillcolor,font=fonts)
    draw.text((110,15),randstr[3],fill=fillcolor,font=fonts)
    b=BytesIO()
    im.save(b,'png')
    resp=HttpResponse(b.getvalue(),'image/png')
    resp.set_cookie('verify',randstr)
    return resp
def verifytext(request):
    code=request.COOKIES.get('verify')
    str={'code':code}
    return JsonResponse(str)
