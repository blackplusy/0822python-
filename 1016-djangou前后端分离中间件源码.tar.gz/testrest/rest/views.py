from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .models import Info
from .serializers import InfoSerializers
from django.http import HttpResponse
class InfoView(viewsets.ModelViewSet):
    queryset=Info.objects.all()
    serializer_class=InfoSerializers
def fetch(request):
    return render(request,'fetch.html')
def xxyy(request):
    return HttpResponse('ok')