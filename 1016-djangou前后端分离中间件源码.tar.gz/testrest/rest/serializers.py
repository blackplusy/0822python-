from rest_framework import serializers
from .models import Info
class InfoSerializers(serializers.ModelSerializer):
    class Meta:
        model=Info#序列化的模型
        fields=('__all__')#字段用元组的类型
