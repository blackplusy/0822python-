from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponse
class MyMiddleware(MiddlewareMixin):
    def process_request(self,request):#请求的时候发生的
        count=request.session.get('count','')
        if count=='':
            count=1
            request.session['count']=1
        else:
            count+=1
            request.session['count']=count
        print('有人请求了你的后台')
        print(count)
        usera=request.META.get('HTTP_USER_AGENT')#获取User_Agent的值
        if usera==None:
            print('你是爬虫，请绕行')
        ip=request.META.get('REMOTE_ADDR')
        print(ip)
        print(usera)
    def process_view(self, request, view_func, view_args, view_kwargs):
        path=request.path
        user=request.session.get('user','')
        if path=='/xxyy/':
            print('你是合法用户')
        else:
            print('你是非法用户')
        if user=='':
            return HttpResponse('你还没有登录')
        else:
            pass

