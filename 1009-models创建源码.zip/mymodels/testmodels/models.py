# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
'''
class Info(models.Model):
    username=models.CharField(max_length=20)
    # varchar(20)
    age=models.IntegerField()
    #int型 ,默认是11
    price=models.DecimalField(max_digits=5,decimal_places=2)
    #decimal型
    #字段:isDelete 实际是真删除，做一个删除标记
    isDelete=models.BooleanField()
    #boolean布尔型  mysql tinyint
    email=models.EmailField(default='',null=True)
    #email类型  邮箱类型 default是django默认的空 null理解成为mysql的一个空 254
    #image=models.ImageField(upload_to='media')
    #图片类型，必须指定图片的上传路径 mysql存成了一个路径
    date=models.DateField(auto_now_add=True)
    time=models.TimeField()
    datetime=models.DateTimeField()
    #以上是日期类型
    text=models.TextField()
    #长文本型，类似于备注字段使用
    url=models.URLField()
    #网址类型
'''
class Author(models.Model):
    name = models.CharField(max_length=10)
    detail = models.ForeignKey(to='AuthorDetail',on_delete=models.CASCADE)
    book=models.ManyToManyField(to='Book')
    class Meta:
        db_table='author'
class Publisher(models.Model):
    name=models.CharField(max_length=20)
    addr=models.CharField(max_length=20)
    class Meta:
        db_table='publisher'
class Book(models.Model):
    title=models.CharField(max_length=20)
    price=models.DecimalField(max_digits=6,decimal_places=2)
    publish_day=models.DateField()
    publisher=models.ForeignKey(Publisher,on_delete=models.CASCADE)
    class Meta:
        db_table='book'
class AuthorDetail(models.Model):
    city=models.CharField(max_length=10)
    class Meta:
        db_table='author_detail'


