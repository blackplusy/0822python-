from django.shortcuts import render
from .task import show
from django.http import HttpResponse
# Create your views here.
def index(request):
    show.delay()
    return HttpResponse('ok')