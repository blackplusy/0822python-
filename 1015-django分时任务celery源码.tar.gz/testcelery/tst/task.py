from celery import task
import time
@task
def show():
    print('hello')
    time.sleep(5)
    print('world')